import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import '@/App.css';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';
import { SettingsProvider } from './context/SettingsContext';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ProductPage from './pages/ProductPage';
import CollectionsPage from './pages/CollectionsPage';
import HeritagePage from './pages/HeritagePage';
import JournalPage from './pages/JournalPage';
import JournalPostPage from './pages/JournalPostPage';
import ContactPage from './pages/ContactPage';
import WishlistPage from './pages/WishlistPage';
import CheckoutPage from './pages/CheckoutPage';
import PaymentSuccessPage from './pages/PaymentSuccessPage';
import PaymentCancelPage from './pages/PaymentCancelPage';
import RecommendationPage from './pages/RecommendationPage';
import AuthPage from './pages/AuthPage';

// Admin
import { AdminAuthProvider } from './admin/AdminAuthContext';
import AdminLayout from './admin/components/AdminLayout';
import AdminLogin from './admin/pages/AdminLogin';
import Dashboard from './admin/pages/Dashboard';
import AdminProducts from './admin/pages/AdminProducts';
import AdminCategories from './admin/pages/AdminCategories';
import AdminTestimonials from './admin/pages/AdminTestimonials';
import AdminJournal from './admin/pages/AdminJournal';
import AdminSettings from './admin/pages/AdminSettings';
import AdminInquiries from './admin/pages/AdminInquiries';
import AdminNewsletter from './admin/pages/AdminNewsletter';
import AdminOrders from './admin/pages/AdminOrders';
import AdminMedia from './admin/pages/AdminMedia';
import AdminActivity from './admin/pages/AdminActivity';
import AdminBackup from './admin/pages/AdminBackup';

const PublicApp = () => (
  <Layout>
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/shop" element={<ShopPage />} />
      <Route path="/product/:slug" element={<ProductPage />} />
      <Route path="/collections" element={<CollectionsPage />} />
      <Route path="/heritage" element={<HeritagePage />} />
      <Route path="/journal" element={<JournalPage />} />
      <Route path="/journal/:slug" element={<JournalPostPage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="/wishlist" element={<WishlistPage />} />
      <Route path="/checkout" element={<CheckoutPage />} />
      <Route path="/payment/success" element={<PaymentSuccessPage />} />
      <Route path="/payment/cancel" element={<PaymentCancelPage />} />
      <Route path="/recommendation" element={<RecommendationPage />} />
      <Route path="/auth" element={<AuthPage />} />
    </Routes>
  </Layout>
);

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <SettingsProvider>
          <AdminAuthProvider>
            <Routes>
              {/* Admin login is public but under /admin/login */}
              <Route path="/admin/login" element={<AdminLogin />} />

              {/* Protected admin console */}
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<Dashboard />} />
                <Route path="products" element={<AdminProducts />} />
                <Route path="categories" element={<AdminCategories />} />
                <Route path="testimonials" element={<AdminTestimonials />} />
                <Route path="journal" element={<AdminJournal />} />
                <Route path="settings" element={<AdminSettings />} />
                <Route path="inquiries" element={<AdminInquiries />} />
                <Route path="newsletter" element={<AdminNewsletter />} />
                <Route path="orders" element={<AdminOrders />} />
                <Route path="media" element={<AdminMedia />} />
                <Route path="activity" element={<AdminActivity />} />
                <Route path="backup" element={<AdminBackup />} />
              </Route>

              {/* Public site */}
              <Route
                path="/*"
                element={
                  <CartProvider>
                    <WishlistProvider>
                      <PublicApp />
                    </WishlistProvider>
                  </CartProvider>
                }
              />
            </Routes>
          </AdminAuthProvider>
        </SettingsProvider>
      </BrowserRouter>
    </div>
  );
}

export default App;
