import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ShoppingBag, Search, Menu, X, Heart, User } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { Dialog, DialogContent, DialogTitle } from './ui/dialog';
import { getProducts } from '../lib/api';
import { formatINR } from '../lib/format';

const MAIN_NAV = [
  { label: 'Shop', href: '/shop' },
  { label: 'Collections', href: '/collections' },
  { label: 'Recommendation', href: '/recommendation' },
  { label: 'Heritage', href: '/heritage' },
  { label: 'Contact', href: '/contact' },
];

const MEGA = [
  { name: 'Ruby', tag: 'Passion & Protection', img: 'https://images.pexels.com/photos/13307186/pexels-photo-13307186.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=500&w=400' },
  { name: 'Emerald', tag: 'Prosperity & Wisdom', img: 'https://images.pexels.com/photos/29495765/pexels-photo-29495765.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=500&w=400' },
  { name: 'Sapphire', tag: 'Truth & Loyalty', img: 'https://images.pexels.com/photos/32988651/pexels-photo-32988651.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=500&w=400' },
  { name: 'Diamond', tag: 'Forever Brilliant', img: 'https://images.pexels.com/photos/8516783/pexels-photo-8516783.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=500&w=400' },
];

const Navbar = () => {
  const { count, setIsOpen } = useCart();
  const { count: wishCount } = useWishlist();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => { setMobileOpen(false); setMegaOpen(false); }, [location.pathname, location.search]);

  useEffect(() => {
    if (!q.trim()) { setResults([]); return; }
    setLoading(true);
    const t = setTimeout(() => {
      getProducts({ search: q, limit: 6 })
        .then(setResults)
        .finally(() => setLoading(false));
    }, 220);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <header
      data-testid="site-header"
      className={`sticky top-0 z-50 transition-colors duration-300 ${
        scrolled ? 'bg-white/90 backdrop-blur-xl border-b border-black/5' : 'bg-white/70 backdrop-blur-md border-b border-transparent'
      }`}
      onMouseLeave={() => setMegaOpen(false)}
    >
      <div className="container-lux flex items-center justify-between h-20">
        <Link to="/" data-testid="logo-link" className="flex items-baseline gap-2 shrink-0">
          <span className="font-serif text-2xl md:text-3xl tracking-tight text-brand-ink">Gemovia</span>
          <span className="w-1.5 h-1.5 rounded-full bg-brand-gold ml-1" />
        </Link>

        <nav className="hidden lg:flex items-center gap-10">
          <Link to="/" data-testid="nav-home" className="overline text-brand-ink/80 hover:text-brand-emerald transition-colors luxe-underline">Home</Link>
          {MAIN_NAV.map((n) => (
            <div
              key={n.href}
              onMouseEnter={() => setMegaOpen(n.label === 'Collections')}
            >
              <Link
                to={n.href}
                data-testid={`nav-${n.label.toLowerCase()}`}
                className="overline text-brand-ink/80 hover:text-brand-emerald transition-colors luxe-underline"
              >
                {n.label}
              </Link>
            </div>
          ))}
        </nav>

        <div className="flex items-center gap-1 md:gap-2">
          <button
            data-testid="search-toggle"
            onClick={() => setSearchOpen(true)}
            className="p-2 hover:text-brand-emerald transition-colors"
            aria-label="Search"
          >
            <Search size={18} />
          </button>
          <Link
            to="/wishlist"
            data-testid="wishlist-link"
            className="relative p-2 hover:text-brand-emerald transition-colors"
            aria-label="Wishlist"
          >
            <Heart size={18} />
            {wishCount > 0 && (
              <span data-testid="wishlist-badge" className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-brand-gold text-brand-ink text-[10px] font-medium flex items-center justify-center px-1">
                {wishCount}
              </span>
            )}
          </Link>
          <Link
            to="/admin/login"
            data-testid="nav-admin-login"
            className="flex items-center gap-1 p-2 text-brand-ink/80 hover:text-brand-emerald transition-colors"
          >
            <User size={18} />
            <span className="hidden sm:inline overline">Admin</span>
          </Link>
          <Link
            to="/auth"
            data-testid="nav-signin-signup"
            className="flex items-center gap-1 p-2 text-brand-ink/80 hover:text-brand-emerald transition-colors"
          >
            <span className="hidden sm:inline overline">Sign in / Sign up</span>
          </Link>
          <button
            data-testid="cart-open-button"
            onClick={() => setIsOpen(true)}
            className="relative p-2 hover:text-brand-emerald transition-colors"
            aria-label="Open cart"
          >
            <ShoppingBag size={18} />
            {count > 0 && (
              <span
                data-testid="cart-count-badge"
                className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-brand-emerald text-white text-[10px] font-medium flex items-center justify-center px-1"
              >
                {count}
              </span>
            )}
          </button>
          <button
            data-testid="mobile-menu-toggle"
            onClick={() => setMobileOpen((v) => !v)}
            className="lg:hidden p-2"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mega menu */}
      {megaOpen && (
        <div
          data-testid="mega-menu"
          className="hidden lg:block absolute left-0 right-0 bg-white border-t border-black/5 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.15)] animate-fade-in"
        >
          <div className="container-lux py-10 grid grid-cols-12 gap-10">
            <div className="col-span-3">
              <p className="overline text-brand-emerald">The Collection</p>
              <h3 className="font-serif text-3xl mt-4 leading-tight">Nine families of<br/>natural marvels.</h3>
              <p className="mt-6 text-sm text-brand-stone leading-relaxed">Explore our curated selection — each stone selected in-person by our master gemologists.</p>
              <Link to="/collections" className="mt-8 inline-block overline text-brand-emerald luxe-underline">Explore all →</Link>
            </div>
            <div className="col-span-9 grid grid-cols-4 gap-4">
              {MEGA.map((m) => (
                <Link
                  key={m.name}
                  to={`/shop?type=${m.name}`}
                  data-testid={`mega-${m.name.toLowerCase()}`}
                  className="group relative overflow-hidden aspect-[3/4]"
                >
                  <img src={m.img} alt={m.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-[900ms] group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <p className="overline text-brand-gold text-[10px]">{m.tag}</p>
                    <p className="font-serif text-2xl text-white mt-1">{m.name}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Mobile */}
      {mobileOpen && (
        <div className="lg:hidden bg-white border-t border-black/5">
          <div className="container-lux py-6 flex flex-col gap-5">
            <Link to="/" data-testid="mobile-nav-home" className="overline text-brand-ink/80 hover:text-brand-emerald">Home</Link>
            {MAIN_NAV.map((n) => (
              <Link
                key={n.href}
                to={n.href}
                data-testid={`mobile-nav-${n.label.toLowerCase()}`}
                className="overline text-brand-ink/80 hover:text-brand-emerald"
              >
                {n.label}
              </Link>
            ))}
            <Link
              to="/auth"
              data-testid="mobile-nav-signin"
              className="overline text-brand-ink/80 hover:text-brand-emerald"
            >
              Sign in / Sign up
            </Link>
            <Link
              to="/admin/login"
              data-testid="mobile-nav-admin"
              className="overline text-brand-ink/80 hover:text-brand-emerald"
            >
              Admin
            </Link>
          </div>
        </div>
      )}

      {/* Search Dialog */}
      <Dialog open={searchOpen} onOpenChange={setSearchOpen}>
        <DialogContent data-testid="search-dialog" className="max-w-2xl bg-white p-0 gap-0 rounded-none border-0 top-[15%] translate-y-0">
          <DialogTitle className="sr-only">Search gemstones</DialogTitle>
          <div className="border-b border-black/10 px-6 py-4 flex items-center gap-4">
            <Search size={18} className="text-brand-stone" />
            <input
              data-testid="search-input"
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search rubies, emeralds, sapphires…"
              className="flex-1 bg-transparent outline-none py-2 text-base placeholder:text-brand-stone/70"
            />
            {q && <button onClick={() => setQ('')} className="text-brand-stone hover:text-brand-ink"><X size={16} /></button>}
          </div>
          <div className="max-h-[60vh] overflow-y-auto">
            {loading && <p className="px-6 py-8 text-sm text-brand-stone">Searching…</p>}
            {!loading && q && results.length === 0 && (
              <p data-testid="search-empty" className="px-6 py-8 text-sm text-brand-stone">No stones match "{q}".</p>
            )}
            {!loading && !q && (
              <div className="px-6 py-8">
                <p className="overline text-brand-stone mb-4">Popular</p>
                <div className="flex flex-wrap gap-2">
                  {['Kashmir Sapphire','Burmese Ruby','Muzo Emerald','Solitaire Diamond','Hessonite Garnet'].map((s) => (
                    <button key={s} onClick={() => setQ(s)} className="text-xs px-3 py-1.5 border border-black/10 hover:border-brand-emerald hover:text-brand-emerald transition-colors">{s}</button>
                  ))}
                </div>
              </div>
            )}
            {results.map((p) => (
              <button
                key={p.id}
                data-testid={`search-result-${p.slug}`}
                onClick={() => { setSearchOpen(false); navigate(`/product/${p.slug}`); }}
                className="w-full flex items-center gap-4 px-6 py-4 hover:bg-neutral-50 text-left border-b border-black/5 last:border-b-0"
              >
                <img src={p.images?.[0]} alt={p.name} className="w-14 h-16 object-cover" />
                <div className="flex-1 min-w-0">
                  <p className="overline text-[10px] text-brand-stone">{p.gemstone_type} · {p.carat} ct</p>
                  <p className="font-serif text-base mt-0.5">{p.name}</p>
                </div>
                <p className="font-serif text-sm">{formatINR(p.price)}</p>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </header>
  );
};

export default Navbar;
