import React from 'react';
import { Link } from 'react-router-dom';

export default function AuthPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="max-w-md w-full p-10 border rounded-md shadow-sm">
        <h1 className="text-2xl font-semibold mb-4">Sign in or Sign up</h1>
        <p className="mb-6 text-sm text-gray-600">This is a placeholder auth page. Integrate your public auth flows here.</p>
        <div className="flex flex-col gap-3">
          <Link to="/login" className="px-4 py-3 bg-brand-emerald text-white rounded text-center">Sign in</Link>
          <Link to="/register" className="px-4 py-3 border border-gray-200 rounded text-center">Sign up</Link>
        </div>
        <p className="mt-6 text-xs text-gray-500">Admin users should use the <Link to="/admin/login" className="text-brand-emerald">Admin login</Link>.</p>
      </div>
    </div>
  );
}
